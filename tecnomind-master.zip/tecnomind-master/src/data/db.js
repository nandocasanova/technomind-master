import image1 from '../assets/photos/imagem1.jpg';
import image2 from '../assets/photos/imagem2.jpg';
import image3 from '../assets/photos/imagem3.jpg';
import image4 from '../assets/photos/imagem4.jpg';
import image5 from '../assets/photos/imagem5.jpg';

const db = [
  {
    name: 'Camila 1',
    description: 'descrição padrao',
    image: image1,
  },
  {
    name: 'Camila 2',
    description: 'descrição padrao',
    image: image2,
  },
  {
    name: 'Camila 3',
    description: 'descrição padrao',
    image: image3,
  },
  {
    name: 'Camila 4',
    description: 'descrição padrao',
    image: image4,
  },
  {
    name: 'Camila 5',
    description: 'descrição padrao',
    image: image5,
  },
];

export default db;
